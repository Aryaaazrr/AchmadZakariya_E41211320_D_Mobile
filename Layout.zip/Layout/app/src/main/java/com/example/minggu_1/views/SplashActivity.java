package com.example.minggu_1.views;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.example.minggu_1.MainActivity;
import com.example.minggu_1.R;
import com.example.minggu_1.views.ui.login.LoginActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // set splash 3 detik
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // instansiasi
                Intent splash = new Intent(SplashActivity.this, LoginActivity.class);
                startActivity(splash);
                finish();
            }
        },3000);
    }
}